package com.jiwoo.payphone;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PayphoneBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(PayphoneBackendApplication.class, args);
	}

}
